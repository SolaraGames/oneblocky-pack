# Glyph reference — tags, icons & emojis

Every glyph below is a single Private-Use-Area codepoint. **Label tags** are
word-mark badges in `U+E16x` (`font/tags/labels/`); **emojis** live in the
`U+E2xx` plane (`font/emojis.png`); **icons** live in `U+E3xx`
(`font/icons/*.png`). They are defined in `font/tags.json`, `font/emoji.json`
and `font/icons.json` and pulled into the default font via `reference`
providers, so they render anywhere vanilla text does (chat, GUIs, item names,
lore, holograms, scoreboard, TAB, …).

To show one in chat, map a placeholder (e.g. `:smile:`) to the codepoint in
whatever chat plugin OneBlocky uses — copy the **Char** cell or use the `\uXXXX`
escape from the **Codepoint** column.

## Label tags &nbsp;·&nbsp; `U+E160 .. U+E16F` &nbsp;·&nbsp; 2 tags
`font/tags/labels/*.png` — one bitmap provider per badge, height 7, ascent 7

| Name | Codepoint | Char |
| --- | --- | --- |
| `oneblock` | `U+E160` |  |
| `profile` | `U+E161` |  |

## Emojis &nbsp;·&nbsp; `U+E200 .. U+E2FF` &nbsp;·&nbsp; 96 glyphs
`font/emojis.png` — grid 16x6, height 10, ascent 8

| Name | Codepoint | Char |
| --- | --- | --- |
| `100` | `U+E200` |  |
| `angry` | `U+E201` |  |
| `arrow_down` | `U+E202` |  |
| `arrow_left` | `U+E203` |  |
| `arrow_lower_left` | `U+E204` |  |
| `arrow_lower_right` | `U+E205` |  |
| `arrow_right` | `U+E206` |  |
| `arrow_up` | `U+E207` |  |
| `arrow_upper_left` | `U+E208` |  |
| `arrow_upper_right` | `U+E209` |  |
| `blue_heart` | `U+E20A` |  |
| `blush` | `U+E20B` |  |
| `box` | `U+E20C` |  |
| `broken_heart` | `U+E20D` |  |
| `check_mark` | `U+E20E` |  |
| `clown` | `U+E20F` |  |
| `cross_mark` | `U+E210` |  |
| `died` | `U+E211` |  |
| `disguised_face` | `U+E212` |  |
| `drooling_face` | `U+E213` |  |
| `exploding_head` | `U+E214` |  |
| `expressionless` | `U+E215` |  |
| `eyes_left` | `U+E216` |  |
| `eyes_right` | `U+E217` |  |
| `face_monocle` | `U+E218` |  |
| `fire` | `U+E219` |  |
| `freeze` | `U+E21A` |  |
| `green_heart` | `U+E21B` |  |
| `grin` | `U+E21C` |  |
| `happy` | `U+E21D` |  |
| `head_bandage` | `U+E21E` |  |
| `heart` | `U+E21F` |  |
| `heart_eyes` | `U+E220` |  |
| `holding_back_tears` | `U+E221` |  |
| `hot_face` | `U+E222` |  |
| `hourglass` | `U+E223` |  |
| `imp` | `U+E224` |  |
| `innocent` | `U+E225` |  |
| `key` | `U+E226` |  |
| `laugh` | `U+E227` |  |
| `locked` | `U+E228` |  |
| `look_left` | `U+E229` |  |
| `look_right` | `U+E22A` |  |
| `minus` | `U+E22B` |  |
| `muscle` | `U+E22C` |  |
| `nerd` | `U+E22D` |  |
| `no_mouth` | `U+E22E` |  |
| `omegalul` | `U+E22F` |  |
| `open_mouth` | `U+E230` |  |
| `orange_heart` | `U+E231` |  |
| `person` | `U+E232` |  |
| `pleading` | `U+E233` |  |
| `plus` | `U+E234` |  |
| `point_down` | `U+E235` |  |
| `point_left` | `U+E236` |  |
| `point_right` | `U+E237` |  |
| `point_up` | `U+E238` |  |
| `poop` | `U+E239` |  |
| `pray` | `U+E23A` |  |
| `purple_heart` | `U+E23B` |  |
| `purple_star` | `U+E23C` |  |
| `pushpin` | `U+E23D` |  |
| `rage` | `U+E23E` |  |
| `raised_eyebrow` | `U+E23F` |  |
| `roblox_head` | `U+E240` |  |
| `rolling_eyes` | `U+E241` |  |
| `sad` | `U+E242` |  |
| `salute` | `U+E243` |  |
| `scream` | `U+E244` |  |
| `sheesh` | `U+E245` |  |
| `shusing` | `U+E246` |  |
| `sick` | `U+E247` |  |
| `skull` | `U+E248` |  |
| `sleep` | `U+E249` |  |
| `smile` | `U+E24A` |  |
| `smiley` | `U+E24B` |  |
| `smiling_face_with_tear` | `U+E24C` |  |
| `smiling_imp` | `U+E24D` |  |
| `sob` | `U+E24E` |  |
| `sparkles` | `U+E24F` |  |
| `star` | `U+E250` |  |
| `star_struck` | `U+E251` |  |
| `stuck_out_tongue` | `U+E252` |  |
| `stuck_out_tongue_closed_eyes` | `U+E253` |  |
| `sunglasses` | `U+E254` |  |
| `thinking` | `U+E255` |  |
| `thumbsdown` | `U+E256` |  |
| `thumbsup` | `U+E257` |  |
| `two_hearts` | `U+E258` |  |
| `unlocked` | `U+E259` |  |
| `upside_down_face` | `U+E25A` |  |
| `vomit` | `U+E25B` |  |
| `warning` | `U+E25C` |  |
| `wink` | `U+E25D` |  |
| `yellow_heart` | `U+E25E` |  |
| `zap` | `U+E25F` |  |

## Currency icons &nbsp;·&nbsp; `U+E300 .. U+E33F` &nbsp;·&nbsp; 20 glyphs
`font/icons/currency.png` — grid 10x2, height 8, ascent 7

| Name | Codepoint | Char |
| --- | --- | --- |
| `bronze_coin` | `U+E300` |  |
| `casino_chip` | `U+E301` |  |
| `coin_pile` | `U+E302` |  |
| `diamond` | `U+E303` |  |
| `emerald` | `U+E304` |  |
| `gem` | `U+E305` |  |
| `gift_box` | `U+E306` |  |
| `glowing_orb` | `U+E307` |  |
| `gold_coin` | `U+E308` |  |
| `mob_coin` | `U+E309` |  |
| `money_pouch` | `U+E30A` |  |
| `paper_banknote` | `U+E30B` |  |
| `ruby` | `U+E30C` |  |
| `sapphire` | `U+E30D` |  |
| `shopping_basket` | `U+E30E` |  |
| `silver_coin` | `U+E30F` |  |
| `ticket` | `U+E310` |  |
| `treasure_chest` | `U+E311` |  |
| `vote_token` | `U+E312` |  |
| `wallet` | `U+E313` |  |

## Effect icons &nbsp;·&nbsp; `U+E340 .. U+E37F` &nbsp;·&nbsp; 40 glyphs
`font/icons/effects.png` — grid 10x4, height 8, ascent 7

| Name | Codepoint | Char |
| --- | --- | --- |
| `absorption` | `U+E340` |  |
| `bad_luck` | `U+E341` |  |
| `bad_omen` | `U+E342` |  |
| `blindness` | `U+E343` |  |
| `breath_of_the_nautilus` | `U+E344` |  |
| `conduit_power` | `U+E345` |  |
| `darkness` | `U+E346` |  |
| `dolphins_grace` | `U+E347` |  |
| `fire_resistance` | `U+E348` |  |
| `glowing` | `U+E349` |  |
| `haste` | `U+E34A` |  |
| `health_boost` | `U+E34B` |  |
| `hero_of_the_village` | `U+E34C` |  |
| `hunger` | `U+E34D` |  |
| `infested` | `U+E34E` |  |
| `instant_damage` | `U+E34F` |  |
| `instant_health` | `U+E350` |  |
| `invisibility` | `U+E351` |  |
| `jump_boost` | `U+E352` |  |
| `levitation` | `U+E353` |  |
| `luck` | `U+E354` |  |
| `mining_fatigue` | `U+E355` |  |
| `nausea` | `U+E356` |  |
| `night_vision` | `U+E357` |  |
| `oozing` | `U+E358` |  |
| `poison` | `U+E359` |  |
| `raid_omen` | `U+E35A` |  |
| `regeneration` | `U+E35B` |  |
| `resistance` | `U+E35C` |  |
| `saturation` | `U+E35D` |  |
| `slow_falling` | `U+E35E` |  |
| `slowness` | `U+E35F` |  |
| `speed` | `U+E360` |  |
| `strength` | `U+E361` |  |
| `trial_omen` | `U+E362` |  |
| `water_breathing` | `U+E363` |  |
| `weakness` | `U+E364` |  |
| `weaving` | `U+E365` |  |
| `wind_charged` | `U+E366` |  |
| `wither` | `U+E367` |  |

## PvP icons &nbsp;·&nbsp; `U+E380 .. U+E3BF` &nbsp;·&nbsp; 24 glyphs
`font/icons/pvp.png` — grid 12x2, height 8, ascent 7

| Name | Codepoint | Char |
| --- | --- | --- |
| `armor` | `U+E380` |  |
| `blood_drop` | `U+E381` |  |
| `bow` | `U+E382` |  |
| `broken_shield` | `U+E383` |  |
| `bronze_medal` | `U+E384` |  |
| `bronze_trophy` | `U+E385` |  |
| `chain_link` | `U+E386` |  |
| `crossed_swords` | `U+E387` |  |
| `crosshair` | `U+E388` |  |
| `crown` | `U+E389` |  |
| `fire` | `U+E38A` |  |
| `gold_medal` | `U+E38B` |  |
| `golden_trophy` | `U+E38C` |  |
| `gravestone` | `U+E38D` |  |
| `heart` | `U+E38E` |  |
| `lightning_bolt` | `U+E38F` |  |
| `potion` | `U+E390` |  |
| `red_flag` | `U+E391` |  |
| `shield` | `U+E392` |  |
| `silver_medal` | `U+E393` |  |
| `silver_trophy` | `U+E394` |  |
| `skull` | `U+E395` |  |
| `stopwatch` | `U+E396` |  |
| `sword` | `U+E397` |  |

## General icons &nbsp;·&nbsp; `U+E3C0 .. U+E3FF` &nbsp;·&nbsp; 38 glyphs
`font/icons/general.png` — grid 19x2, height 8, ascent 7

| Name | Codepoint | Char |
| --- | --- | --- |
| `2head` | `U+E3C0` |  |
| `anvil` | `U+E3C1` |  |
| `arrow_down` | `U+E3C2` |  |
| `arrow_up` | `U+E3C3` |  |
| `border` | `U+E3C4` |  |
| `cancel` | `U+E3C5` |  |
| `clock` | `U+E3C6` |  |
| `coin` | `U+E3C7` |  |
| `compass` | `U+E3C8` |  |
| `confirm` | `U+E3C9` |  |
| `emerald` | `U+E3CA` |  |
| `gem` | `U+E3CB` |  |
| `heads` | `U+E3CC` |  |
| `heart` | `U+E3CD` |  |
| `house` | `U+E3CE` |  |
| `key` | `U+E3CF` |  |
| `light_blub` | `U+E3D0` |  |
| `light_blub2` | `U+E3D1` |  |
| `location_pin` | `U+E3D2` |  |
| `mana` | `U+E3D3` |  |
| `mana_empty` | `U+E3D4` |  |
| `money` | `U+E3D5` |  |
| `moon` | `U+E3D6` |  |
| `paper` | `U+E3D7` |  |
| `player` | `U+E3D8` |  |
| `player_steve` | `U+E3D9` |  |
| `portal` | `U+E3DA` |  |
| `sapling` | `U+E3DB` |  |
| `skull` | `U+E3DC` |  |
| `skullbones` | `U+E3DD` |  |
| `spruce_house` | `U+E3DE` |  |
| `star` | `U+E3DF` |  |
| `sword` | `U+E3E0` |  |
| `tower` | `U+E3E1` |  |
| `trophy` | `U+E3E2` |  |
| `water_drop` | `U+E3E3` |  |
| `water_drop_icon` | `U+E3E4` |  |
| `wheat` | `U+E3E5` |  |
